$(document).ready(function() {
  load_editors();
});

function load_editors(){
  $('.editor').tinymce({
  //removed settings to keep it short.
  });
}
